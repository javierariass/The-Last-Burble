
thank you for using the bitByBit_ tileset...from the bitByBit_ series' on itch.io!



stuff to know - tilesets

- each tile is 8 x 8 pixels...although some structures/objcets take up multiple tiles [e.g. spring, flag, etc]
- the tileset consists of:
 - ground tiles [yellow], platforms and a spring [red], traps [light grey], one way platforms [dark grey], 4 player/enemy sprites [red, yellow, green and blue], a sign [dark red] and a flag [dark grey/dark grey, black and white]



...if you have any questions or requests you can contact me at analogstudios.inc@gmail.com





                                                             